TOKEN = "MTM4MTgzNTYxOTU2NjYyMDc2Mg.GN3PUs.E6TNseBIkoznk60Hv5tXgnat1Rnn1mxqwUOWDc"  # Your bot token string
GUILD_ID = 888920978065870859  # Your server (guild) ID as an integer
CATEGORY_ID = 1381838954617372763  # The category ID for ticket channels
STAFF_ROLE_ID = 1381841089396215808  # The staff role ID for permissions
TRANSCRIPT_CHANNEL_ID = 1381843210699014215  # Replace with your transcript channel ID
